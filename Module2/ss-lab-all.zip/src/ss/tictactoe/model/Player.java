package ss.tictactoe.model;

/**
 * A player of a turn-based game.
 */
public interface Player {
}
