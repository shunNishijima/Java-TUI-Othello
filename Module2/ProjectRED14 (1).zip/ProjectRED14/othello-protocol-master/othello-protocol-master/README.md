# Othello protocol

This repository contains the documentation for the protocol used to communicate between clients and servers for Othello.

For a description of the mandatory set of commands, see [commands.md](commands.md).

Possible extensions can be found in the extensions subdirectory. 