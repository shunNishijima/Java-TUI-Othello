package ss.week4;

import java.util.ArrayList;
import java.util.List;

public class MergeSort {

	//@ requires data != null;
	/*@
		ensures (\forall int i;
			i >= 0 && i < data.size() - 1;
			data.get(i).compareTo(data.get(i + 1)) <= 0);
	*/
	// This is an alternative option for the postcondition above.
	/*@
		ensures (\forall int i,j;
		i >= 0 && i < data.size() && j >= 0 && j < data.size();
		i <= j ==> data.get(i).compareTo(data.get(j)) <= 0);
	*/
	public static <E extends Comparable<E>> List<E> mergeSort(List<E> data) {
		 // TODO: implement, see exercise P-4.3
		List<E> result = null;
		return result;
	}

}
